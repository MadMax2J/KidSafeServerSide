<?php
/**
 * db_config.php
 * Created by PhpStorm.
 * User: jbyrne
 * Date: 02/03/2015
 * Time: 15:54
 */

/**
 * All database connection variables
 */

define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password (mention your db password here)
define('DB_DATABASE', "kidsafe"); // database name
define('DB_SERVER', "localhost"); // db server
?>